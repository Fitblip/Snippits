'''
Created on Oct 7, 2011

@author: Administrator
'''
from ctypes import *
from my_debugger_defines import *

kernel32 = windll.kernel32

class debugger():
        def __init__(self):
            pass
        
        def load(self,path_to_exe):
            
            # dwCreation flag determines how to create the process
            # set creation_flags = CREATE_NEW_CONSOLE if you want
            # to see calc.exe's GUI
            
            creation_flags      = CREATE_NEW_CONSOLE
            
            # Instantiate the structs
            startupinfo         = STARTUPINFO()
            process_information = PROCESS_INFORMATION()
            
            # The following options allow the started process
            # to be shown as a seperate window and whatnot
            # Also illustrates how different settings in STARTUPINFO
            # can effect the debugee
            
            startupinfo.dwFlags = 0x1
            startupinfo.wShowWindow = 0x1
            
            # We then init the cb variable in STARTUPINFO struct which is
            # just the size of the struct itself
            
            startupinfo.cb = sizeof(startupinfo)
            if kernel32.CreateProcessA(
                                       path_to_exe,
                                       None,
                                       None,
                                       None,
                                       None,
                                       creation_flags,
                                       None,
                                       None,
                                       byref(startupinfo),
                                       byref(process_information)):
                print "[*] We have launched the process! Yay!"
                print "[*] PID: %d" % process_information.dwProcessId
                print "[*] Thread ID : %d" % process_information.dwThreadId
                print "[*] CB : %s" % startupinfo.cb
                
            else:
                
                print "[*] Error: 0x%08x." % kernel32.GetLastError()
                
