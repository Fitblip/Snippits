'''
Created on Oct 7, 2011

@author: Administrator
'''

from ctypes import *

"""

#
##
#### Example 1
##
#

msvcrt = cdll.msvcrt
message_string = "Heyo!"
msvcrt.printf("Your string, sir => %s", message_string)

"""
""" 

#
##
#### Example 2
##
#
 
class barley_amt(Union):
    _fields_ = [
               ("barley_long", c_long),
               ("barley_int", c_int),
               ("barley_char", c_char * 8 ),
               ]

value = raw_input("Enter amount of barley to put in vat : ")
my_barley = barley_amt(int(value))

print "Barley amt as LONG : %ld" % my_barley.barley_long
print "Barley amt as INT : %d" % my_barley.barley_int
print "Barley amt as CHAR : %s" % my_barley.barley_char

"""

